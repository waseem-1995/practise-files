import React from 'react'
import Todo from '../Components/Todo'

const Homepage = () => {
  return (
    <div>Hompage
      <Todo/>
    </div>
  )
}

export default Homepage