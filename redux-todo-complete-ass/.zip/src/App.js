import './App.css';
import Allroute from './Pages/Allroute';

function App() {
  return (
    <div className="App">
      <Allroute/>
    </div>
  );
}

export default App;
